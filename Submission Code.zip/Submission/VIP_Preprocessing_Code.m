% VIP Image Processing and Data Visualization
% Final Project
% Pre-processing of the cell images

%% Clear up the workspace and console
clc
clear all

%% Import the desired cell to pre process
I = imread("Cell_59_Actin.tif"); % load in the cell image to pre process
[counts, binLocations] = imhist(I); % compute and display the histogram of the image
%imhist(I);
%imshow(I,[]);

%% Begin the pre processing
I_eq = histeq(I); % equalize the historgram -> enhances contrast, makes the cell easier to see

denoisedFrame = medfilt2(I_eq, [5,5]); %reduces the noise (median filtering) so the image is more clear

I_bw = imbinarize(denoisedFrame,'adaptive'); %Binarize the iamge

%The below two lines create structuring elements that will be used for
%morphological operations
se90 = strel('line',3,90);
se0 = strel('line',3,0);

I_fill = edge(I_bw); %This performs edge detection for the cell/object
%imshow(I_eq,[]);

%The following lines have the edge detection threshold being calculated
%using Sobel
[~,threshold] = edge(I_eq,'sobel');
fudgeFactor = 0.4; % included because sometimes the insides of the cells would be viewed as edges, removing some features including the stress fibers
BWs = edge(I_eq,'sobel',threshold * fudgeFactor); 

% Dilate the edges to connect nearby regions
se90 = strel('line',8,90);
se0 = strel('line',8,0);
BWsdil = imdilate(BWs,[se90 se0]);

%remove unnecessary objects from the image
test = bwareaopen(~BWsdil,300, 8); % Small objects are removed
test = imclearborder(test); % objects that are touching the border are removed (remove this if the main cell in frame touches the borders)


denoisedFrame = medfilt2(BWsdil, [5,5]); %encountered more noise so do more noise reduction
%imshow(test,[]);

I_eq(~test) = 0; % Applios the mask to the original image
I_test = histeq(I_eq); % histogram equalization is performed again to improve contrast, but this time on the image with the mask
%I_Cell = I_test;

I_Cell = mat2gray(I_test); % converted to grayscale to make the contrast even better for the hand segmentation

%% Now we can display and save our final processed image
imshow(I_Cell, []); %comment this out when running the app
%figure(2);
%imhist(I_Cell);
imwrite(I_Cell, "PP_Cell_77_Actin.tif"); % saves the pre processed image as a tif file