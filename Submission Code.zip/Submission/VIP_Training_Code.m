%VIP Image Processing and Data Visualization
% Final Project
% Training the Neural Net

Clear workspace and console for neatness
clc;
clear all;

%% start loading in the different datastores for information including the training images, the bounding boxes, the labels, and the masks

imds_Image = imageDatastore('DeepLearningData', "FileExtensions", ".mat", 'ReadFcn', @(x) double(load(x) .ReturnArray{1})); %This stores the image datastore

Boxes =  datastore('DeepLearningData', 'Type', 'file', 'ReadFcn', @ (x) (load(x). ReturnArray{2})); %this creates the bounding boxes datastore

Labels = datastore ('DeepLearningData', 'Type', 'file', 'ReadFcn', @ (x) categorical(load(x). ReturnArray{3})); % this creates the labels datastore

blds = boxLabelDatastore(table(readall(Boxes), readall(Labels))); % create a datastore that combines the labels and bounding boxes

imds_Mask = imageDatastore('DeepLearningData', "FileExtensions", ".mat", 'ReadFcn', @(x) load(x).ReturnArray{4}); %this creates the overall mask datastore

%% Now prepare more aspects for the training
TrainingData = combine(imds_Image, blds, imds_Mask); %Combine all of the datastores into one set of data

trainClassNames=categorical(["Actin"]); % set the class name (we used Actin just because we know it's the only one)

imageSizeTrain = [1940 1460 3]; %This is the image size of the inputs

net = maskrcnn("resnet50-coco", trainClassNames,InputSize=imageSizeTrain); %This creates the Mask R-CNN network, which uses the resnet50-coco backbone to assist in training

%This is the options definition - we set the Initial learn rate to be very
%small, and did a maximum of 11 Epochs to try to improve the training loss
%metrics. Additionally, the mini batch size of 1 was chosen because we had
%a small amount of training data, so we wanted it to be thorough
options = trainingOptions("sgdm", ...
    InitialLearnRate=0.0001, ...
    LearnRateSchedule="piecewise", ...
    LearnRateDropPeriod=1, ...
    LearnRateDropFactor=0.95, ...
    Plot="none", ...
    Momentum=0.9, ...
    MaxEpochs=11, ...
    MiniBatchSize=1, ...
    BatchNormalizationStatistics="moving", ...
    ResetInputNormalization=false, ...
    ExecutionEnvironment="cpu", ...
    Plots="training-progress",...
    VerboseFrequency=1);

%% Now we finally train the net
[net, info] = trainMaskRCNN(TrainingData, net, options, FreezeSubNetwork = "backbone"); %The Mask R-CNN network is trained using the data in this line of code
save("VIP_Actin_Training.mat","net"); %The output trained neural net is saved as VIP_Actin_Training.mat