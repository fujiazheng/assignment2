% VIP Image Processing and Data Visualization
% Final Project
% Analyzing the segmentation algorithm - IMPORTANT -> meant to be ran AFTER running
% VIP_Segmentation_Code.m, ran into issues running them at the same time

%% We want to generate some metrics to evaluate how effective our segmentation was based on our ground truths

model= load("VIP_Actin_Training.mat"); % The trained net is loaded in
detector= model.net; % again, the trained neural net is stored as a variable
imProcessed = imageDatastore('PP_Cell_64_Actin.tif'); % Load in the image we want to compare the ground truth to

% the three lines of code that follow are used to pull the desired aspects
% of the ground truth so we can use it to compare to the test results
% (labels and masks). They are then combined as groundtruth
groundTruth_label=datastore ('Test_Data', 'Type', 'file', 'ReadFcn', @ (x) categorical(load(x). ReturnArray{3}));
groundTruth_mask=imageDatastore('Test_Data', "FileExtensions", ".mat", 'ReadFcn', @(x) load (x). ReturnArray{4});
groundtruth=combine(groundTruth_mask,groundTruth_label);

%the effectiveness metrics for segmentation are output, including a
%confusion matrix
metrics= evaluateInstanceSegmentation(ourResult,groundtruth);