% VIP Image Processing and Data Visualization
% Final Project
% Applying the Trained Net to Segment Images

%% First we will load the net in
model = load("VIP_Actin_Training.mat"); % this directly loads in the saved trained net that was trained in the training code
detector = model.net; % this stores our net as a variable that we can call later

%% Now we load the desired image
i = load('Cell_77_Actin_new.mat'); % this loads in the image we want to segment
imageProcessed = i.ReturnArray{1}; %this sets the variable which contains the processed cell image that will be segmented

%% Next we setup a figure and perform the segmentation, where the mask with detected objects can be observed
figure;
imshow(imageProcessed); %display the original image
title('Original Image'); %label the figure

[masks,labels,scores,bboxes] = segmentObjects(detector,imageProcessed, Threshold=0.3); % Segmentation is performed here by applying the trained net

% This if-else statement applys the bounding boxes of the detected objects
% to the image of the cell, so the detected objects can be visualized
if isempty(bboxes)
    disp('No objects detected.');
else
    for idx = 1:size(bboxes, 1)
        rectangle('Position', bboxes(idx, :), 'EdgeColor', 'r', 'LineWidth', 2);
    end
end
hold off;